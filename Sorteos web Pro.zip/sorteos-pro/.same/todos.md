# SorteosPro - Todos

## Completado
- [x] Crear estructura del proyecto con Next.js y shadcn/ui
- [x] Diseñar Hero section con selector de plataforma
- [x] Crear componente principal de sorteo (GiveawayPicker)
- [x] Soporte para Instagram, Facebook y TikTok
- [x] Monitoreo de comentarios, likes, shares y reposts
- [x] Filtros avanzados (excluir duplicados, requerir mención)
- [x] Selector de número de ganadores
- [x] Animación de confetti para ganadores
- [x] Sección de herramientas populares
- [x] Sección de características
- [x] Sección "Cómo funciona"
- [x] FAQ con acordeón
- [x] Footer completo
- [x] Arreglar error de hidratación con Math.random()
- [x] **NUEVO: Modo Multi-Plataforma** - Sorteo simultaneo en Instagram, Facebook y TikTok
  - [x] Botón Multi-Red en selector de plataformas
  - [x] Inputs separados para cada plataforma
  - [x] Switch para habilitar/deshabilitar cada plataforma
  - [x] Estadísticas separadas por plataforma
  - [x] Indicador de plataforma en participantes y ganadores
  - [x] Gradiente especial para modo multi-plataforma

## Pendiente
- [ ] Agregar Rueda de la Fortuna (opcional)
- [ ] Agregar Sorteo de Nombres (opcional)
- [ ] Conectar con APIs reales de redes sociales (requiere autenticación)
- [ ] Sistema de autenticación de usuarios
- [ ] Base de datos para guardar sorteos
- [ ] Generación de certificados PDF
