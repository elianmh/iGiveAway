'use client';

import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';

const steps = [
  {
    number: 1,
    title: 'Selecciona el Post',
    description:
      'Elige el post de tu cuenta donde los participantes han interactuado con comentarios, likes, shares o reposts.',
  },
  {
    number: 2,
    title: 'Aplica Filtros',
    description:
      'Filtra rapidamente las interacciones que cumplen con los requisitos propuestos: hashtags, menciones, excluir duplicados, etc.',
  },
  {
    number: 3,
    title: 'Elige el Tipo de Interaccion',
    description:
      'Selecciona si quieres sortear entre comentarios, likes, shares, reposts o una combinacion de todos.',
  },
  {
    number: 4,
    title: 'Elige el Ganador',
    description:
      'SorteosPro seleccionara automaticamente al ganador o ganadores, tomando en cuenta los filtros aplicados.',
  },
];

export function HowItWorks() {
  return (
    <section id="como-funciona" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Como Funciona: 4 Simples Pasos
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Crea un sorteo exitoso en menos de 5 minutos
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          {steps.map((step, index) => (
            <Card
              key={step.number}
              className="relative border-2 hover:border-primary/30 transition-all duration-300 hover:shadow-lg"
            >
              <CardContent className="pt-8 pb-6 px-6">
                <div className="absolute -top-5 left-6">
                  <span className="flex h-10 w-10 items-center justify-center rounded-full gradient-primary text-white font-bold text-lg shadow-lg">
                    {step.number}
                  </span>
                </div>
                <h3 className="font-bold text-lg mb-2 mt-2">{step.title}</h3>
                <p className="text-sm text-muted-foreground">{step.description}</p>
              </CardContent>
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-1/2 -right-3 transform -translate-y-1/2 text-primary/30 text-2xl">
                  →
                </div>
              )}
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
