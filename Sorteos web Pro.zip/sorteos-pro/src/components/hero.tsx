'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  InstagramIcon,
  FacebookIcon,
  TikTokIcon,
  ArrowRightIcon,
  StarIcon,
} from '@/components/icons';
import { cn } from '@/lib/utils';

const platforms = [
  { id: 'instagram', icon: InstagramIcon, name: 'Instagram' },
  { id: 'facebook', icon: FacebookIcon, name: 'Facebook' },
  { id: 'tiktok', icon: TikTokIcon, name: 'TikTok' },
];

export function Hero() {
  const [selectedPlatform, setSelectedPlatform] = useState('instagram');

  return (
    <section className="relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 gradient-hero" />

      {/* Decorative elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 bg-white/5 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-white/5 rounded-full blur-3xl" />
        <div className="absolute top-40 right-20 w-4 h-4 bg-white/30 rounded-full animate-pulse" />
        <div className="absolute top-60 left-1/4 w-3 h-3 bg-white/20 rounded-full animate-pulse delay-300" />
        <div className="absolute bottom-40 left-20 w-2 h-2 bg-white/40 rounded-full animate-pulse delay-500" />
      </div>

      <div className="relative container mx-auto px-4 py-20 md:py-28">
        <div className="max-w-4xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 text-white mb-6 animate-float">
            <span className="flex gap-0.5">
              {[1, 2, 3, 4, 5].map((i) => (
                <StarIcon key={i} className="h-4 w-4 text-yellow-400" />
              ))}
            </span>
            <span className="text-sm">Usado por +10,000 creadores</span>
          </div>

          {/* Title */}
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
            Sorteos de Redes Sociales
            <br />
            <span className="text-white/90">Facil y Gratis</span>
          </h1>

          {/* Subtitle */}
          <p className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto mb-10">
            Elige ganadores de <strong>comentarios, likes, shares y reposts</strong> de Instagram,
            Facebook y TikTok. 100% gratis y transparente.
          </p>

          {/* Platform selector */}
          <div className="flex justify-center gap-2 mb-6">
            {platforms.map((platform) => {
              const Icon = platform.icon;
              return (
                <button
                  key={platform.id}
                  type="button"
                  onClick={() => setSelectedPlatform(platform.id)}
                  className={cn(
                    'flex items-center gap-2 px-4 py-2 rounded-full font-medium transition-all duration-200',
                    selectedPlatform === platform.id
                      ? 'bg-white text-gray-900 shadow-lg'
                      : 'bg-white/10 text-white hover:bg-white/20'
                  )}
                >
                  <Icon className="h-4 w-4" />
                  <span className="hidden sm:inline">{platform.name}</span>
                </button>
              );
            })}
          </div>

          {/* Search input */}
          <div className="max-w-xl mx-auto">
            <div className="flex gap-2 p-2 bg-white rounded-2xl shadow-2xl">
              <Input
                placeholder="Ingresa @usuario o URL del post..."
                className="flex-1 h-14 border-0 text-lg focus-visible:ring-0 px-4"
              />
              <Button className="h-14 px-8 gradient-primary text-white font-semibold text-lg rounded-xl shadow-lg hover:shadow-xl transition-all hover:scale-105">
                Comenzar
                <ArrowRightIcon className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Features list */}
          <div className="flex flex-wrap justify-center gap-6 mt-10">
            {[
              'Comentarios',
              'Likes',
              'Shares',
              'Reposts',
            ].map((feature) => (
              <div key={feature} className="flex items-center gap-2 text-white/80">
                <div className="w-2 h-2 rounded-full bg-white/60" />
                <span>{feature}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Wave divider */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg
          viewBox="0 0 1440 120"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full"
        >
          <path
            d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z"
            fill="white"
          />
        </svg>
      </div>
    </section>
  );
}
