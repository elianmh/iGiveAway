'use client';

import { Card, CardContent } from '@/components/ui/card';
import {
  InstagramIcon,
  FacebookIcon,
  TikTokIcon,
  WheelIcon,
  ListIcon,
  DiceIcon,
  HashIcon,
  Share2Icon,
  ArrowRightIcon,
} from '@/components/icons';
import { cn } from '@/lib/utils';

interface Tool {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  bgClass: string;
}

const tools: Tool[] = [
  {
    id: 'instagram',
    name: 'Sorteo Instagram',
    description: 'Elige ganadores de comentarios, likes y mas de tus posts',
    icon: <InstagramIcon className="h-6 w-6" />,
    color: '#E4405F',
    bgClass: 'bg-instagram',
  },
  {
    id: 'facebook',
    name: 'Sorteo Facebook',
    description: 'Selecciona ganadores de tus publicaciones de Facebook',
    icon: <FacebookIcon className="h-6 w-6" />,
    color: '#1877F2',
    bgClass: 'bg-facebook',
  },
  {
    id: 'tiktok',
    name: 'Sorteo TikTok',
    description: 'Sortea entre comentarios, likes, shares y reposts de TikTok',
    icon: <TikTokIcon className="h-6 w-6" />,
    color: '#000000',
    bgClass: 'bg-tiktok',
  },
  {
    id: 'wheel',
    name: 'Rueda de la Fortuna',
    description: 'Gira la rueda y obtén un ganador al azar',
    icon: <WheelIcon className="h-6 w-6" />,
    color: '#e12e9f',
    bgClass: 'gradient-primary',
  },
  {
    id: 'names',
    name: 'Sorteo de Nombres',
    description: 'Ingresa una lista de nombres y elige ganadores',
    icon: <ListIcon className="h-6 w-6" />,
    color: '#10B981',
    bgClass: 'bg-emerald-500',
  },
  {
    id: 'multi',
    name: 'Multi-Red',
    description: 'Combina participantes de múltiples redes sociales',
    icon: <Share2Icon className="h-6 w-6" />,
    color: '#8B5CF6',
    bgClass: 'bg-violet-500',
  },
];

export function ToolsGrid() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Herramientas de Sorteo Populares
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Mas de 6 aplicaciones para realizar sorteos online y hacer crecer tu marca
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {tools.map((tool) => (
            <Card
              key={tool.id}
              className="group border-2 hover:border-primary/30 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 cursor-pointer overflow-hidden"
            >
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div
                    className={cn(
                      'flex h-14 w-14 shrink-0 items-center justify-center rounded-xl text-white shadow-lg transition-transform duration-300 group-hover:scale-110',
                      tool.bgClass
                    )}
                  >
                    {tool.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-lg mb-1 flex items-center gap-2">
                      {tool.name}
                      <ArrowRightIcon className="h-4 w-4 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300" />
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {tool.description}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
