'use client';

import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import {
  InstagramIcon,
  FacebookIcon,
  TikTokIcon,
  HeartIcon,
  MessageCircleIcon,
  Share2Icon,
  RepeatIcon,
  PlayIcon,
  FilterIcon,
  TrophyIcon,
  SparklesIcon,
  RefreshIcon,
  UsersIcon,
  DownloadIcon,
  CheckIcon,
  ArrowRightIcon,
} from '@/components/icons';
import { cn } from '@/lib/utils';
import type { Platform, InteractionType, Participant, Winner } from '@/lib/types';
import { platformConfig, interactionConfig } from '@/lib/types';
import { generateMockParticipants, pickRandomWinners } from '@/lib/mock-data';
import { Confetti } from './confetti';

type PlatformMode = Platform | 'multi';

interface PlatformUrl {
  platform: Platform;
  url: string;
  enabled: boolean;
}

interface GiveawayPickerProps {
  defaultPlatform?: Platform;
}

export function GiveawayPicker({ defaultPlatform = 'instagram' }: GiveawayPickerProps) {
  const [platformMode, setPlatformMode] = useState<PlatformMode>(defaultPlatform);
  const [postUrl, setPostUrl] = useState('');
  const [multiPlatformUrls, setMultiPlatformUrls] = useState<PlatformUrl[]>([
    { platform: 'instagram', url: '', enabled: true },
    { platform: 'facebook', url: '', enabled: true },
    { platform: 'tiktok', url: '', enabled: true },
  ]);
  const [selectedInteractions, setSelectedInteractions] = useState<InteractionType[]>(['comments']);
  const [winnersCount, setWinnersCount] = useState(1);
  const [excludeDuplicates, setExcludeDuplicates] = useState(true);
  const [requireMention, setRequireMention] = useState(false);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [winners, setWinners] = useState<Winner[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isPickingWinner, setIsPickingWinner] = useState(false);
  const [currentStep, setCurrentStep] = useState<'input' | 'participants' | 'winner'>('input');
  const [showConfetti, setShowConfetti] = useState(false);

  // Get available interactions based on mode
  const getAvailableInteractions = (): InteractionType[] => {
    if (platformMode === 'multi') {
      // In multi mode, show all possible interactions
      return ['comments', 'likes', 'shares', 'reposts'];
    }
    return platformConfig[platformMode].supportedInteractions;
  };

  const availableInteractions = getAvailableInteractions();

  useEffect(() => {
    // Reset selected interactions when platform changes
    setSelectedInteractions(['comments']);
  }, [platformMode]);

  const handleInteractionToggle = (interaction: InteractionType) => {
    setSelectedInteractions((prev) => {
      if (prev.includes(interaction)) {
        if (prev.length === 1) return prev;
        return prev.filter((i) => i !== interaction);
      }
      return [...prev, interaction];
    });
  };

  const handleMultiPlatformUrlChange = (platform: Platform, url: string) => {
    setMultiPlatformUrls((prev) =>
      prev.map((p) => (p.platform === platform ? { ...p, url } : p))
    );
  };

  const handleMultiPlatformToggle = (platform: Platform) => {
    setMultiPlatformUrls((prev) =>
      prev.map((p) => (p.platform === platform ? { ...p, enabled: !p.enabled } : p))
    );
  };

  const handleLoadParticipants = async () => {
    if (platformMode !== 'multi' && !postUrl) return;
    if (platformMode === 'multi' && !multiPlatformUrls.some((p) => p.enabled && p.url)) return;

    setIsLoading(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000));

    const allParticipants: Participant[] = [];

    if (platformMode === 'multi') {
      // Generate participants for each enabled platform
      for (const platformUrl of multiPlatformUrls) {
        if (platformUrl.enabled && platformUrl.url) {
          for (const interactionType of selectedInteractions) {
            // Check if this platform supports this interaction
            if (platformConfig[platformUrl.platform].supportedInteractions.includes(interactionType)) {
              const count = Math.floor(Math.random() * 150) + 30;
              const mockParticipants = generateMockParticipants(count, interactionType);
              // Add platform info to each participant
              const participantsWithPlatform = mockParticipants.map((p) => ({
                ...p,
                id: `${platformUrl.platform}-${p.id}`,
                platform: platformUrl.platform,
              }));
              allParticipants.push(...participantsWithPlatform);
            }
          }
        }
      }
    } else {
      // Single platform mode
      for (const interactionType of selectedInteractions) {
        const count = Math.floor(Math.random() * 200) + 50;
        const mockParticipants = generateMockParticipants(count, interactionType);
        const participantsWithPlatform = mockParticipants.map((p) => ({
          ...p,
          platform: platformMode,
        }));
        allParticipants.push(...participantsWithPlatform);
      }
    }

    setParticipants(allParticipants);
    setIsLoading(false);
    setCurrentStep('participants');
  };

  const handlePickWinners = useCallback(async () => {
    setIsPickingWinner(true);
    setShowConfetti(false);

    // Simulate picking animation
    await new Promise((resolve) => setTimeout(resolve, 2000));

    const filteredParticipants = excludeDuplicates
      ? participants.filter(
          (p, i, arr) => arr.findIndex((x) => x.username === p.username) === i
        )
      : participants;

    const selectedWinners = pickRandomWinners(filteredParticipants, winnersCount).map(
      (p, index) => ({
        ...p,
        position: index + 1,
      })
    );

    setWinners(selectedWinners);
    setIsPickingWinner(false);
    setCurrentStep('winner');
    setShowConfetti(true);
  }, [participants, excludeDuplicates, winnersCount]);

  const handleReset = () => {
    setPostUrl('');
    setMultiPlatformUrls([
      { platform: 'instagram', url: '', enabled: true },
      { platform: 'facebook', url: '', enabled: true },
      { platform: 'tiktok', url: '', enabled: true },
    ]);
    setParticipants([]);
    setWinners([]);
    setCurrentStep('input');
    setShowConfetti(false);
  };

  const getPlatformIcon = (p: Platform) => {
    switch (p) {
      case 'instagram':
        return <InstagramIcon className="h-5 w-5" />;
      case 'facebook':
        return <FacebookIcon className="h-5 w-5" />;
      case 'tiktok':
        return <TikTokIcon className="h-5 w-5" />;
    }
  };

  const getInteractionIcon = (type: InteractionType) => {
    switch (type) {
      case 'comments':
        return <MessageCircleIcon className="h-4 w-4" />;
      case 'likes':
        return <HeartIcon className="h-4 w-4" />;
      case 'shares':
        return <Share2Icon className="h-4 w-4" />;
      case 'reposts':
        return <RepeatIcon className="h-4 w-4" />;
    }
  };

  const getParticipantsByPlatform = (platform: Platform) => {
    return participants.filter((p) => p.platform === platform);
  };

  const isMultiMode = platformMode === 'multi';

  return (
    <div className="w-full max-w-4xl mx-auto">
      {showConfetti && <Confetti />}

      {/* Platform Selector */}
      <div className="flex flex-wrap justify-center gap-2 mb-8">
        {(Object.keys(platformConfig) as Platform[]).map((p) => (
          <button
            key={p}
            type="button"
            onClick={() => setPlatformMode(p)}
            className={cn(
              'flex items-center gap-2 px-5 py-3 rounded-xl font-medium transition-all duration-300',
              platformMode === p
                ? `${platformConfig[p].bgClass} text-white shadow-lg scale-105`
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            )}
          >
            {getPlatformIcon(p)}
            <span>{platformConfig[p].name}</span>
          </button>
        ))}
        {/* Multi-platform button */}
        <button
          type="button"
          onClick={() => setPlatformMode('multi')}
          className={cn(
            'flex items-center gap-2 px-5 py-3 rounded-xl font-medium transition-all duration-300',
            platformMode === 'multi'
              ? 'bg-gradient-to-r from-[#450063] via-[#9414d1] to-[#03b2ed] text-white shadow-lg scale-105'
              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          )}
        >
          <div className="flex -space-x-1">
            <InstagramIcon className="h-4 w-4" />
            <FacebookIcon className="h-4 w-4" />
            <TikTokIcon className="h-4 w-4" />
          </div>
          <span>Multi-Red</span>
        </button>
      </div>

      {/* Main Card */}
      <Card className="border-2 shadow-2xl overflow-hidden">
        {/* Header with gradient */}
        <div className={cn(
          'p-6 text-white',
          isMultiMode
            ? 'bg-gradient-to-r from-[#450063] via-[#9414d1] to-[#03b2ed]'
            : platformConfig[platformMode as Platform].bgClass
        )}>
          <h2 className="text-2xl md:text-3xl font-bold flex items-center gap-3">
            {isMultiMode ? (
              <>
                <div className="flex -space-x-1">
                  <InstagramIcon className="h-6 w-6" />
                  <FacebookIcon className="h-6 w-6" />
                  <TikTokIcon className="h-6 w-6" />
                </div>
                Sorteo Multi-Plataforma
              </>
            ) : (
              <>
                {getPlatformIcon(platformMode as Platform)}
                Sorteo de {platformConfig[platformMode as Platform].name}
              </>
            )}
          </h2>
          <p className="mt-2 opacity-90">
            {isMultiMode
              ? 'Combina participantes de Instagram, Facebook y TikTok en un solo sorteo'
              : 'Selecciona ganadores de comentarios, likes, shares y reposts'}
          </p>
        </div>

        <CardContent className="p-6">
          {currentStep === 'input' && (
            <div className="space-y-6">
              {/* Single Platform URL Input */}
              {!isMultiMode && (
                <div className="space-y-2">
                  <Label htmlFor="postUrl" className="text-base font-semibold">
                    URL del Post o @usuario
                  </Label>
                  <div className="relative">
                    <Input
                      id="postUrl"
                      value={postUrl}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPostUrl(e.target.value)}
                      placeholder={`Ej: https://${platformMode}.com/p/abc123`}
                      className="h-14 pl-4 pr-12 text-lg border-2 focus:border-primary rounded-xl"
                    />
                    <div className="absolute right-4 top-1/2 -translate-y-1/2 opacity-50">
                      {getPlatformIcon(platformMode as Platform)}
                    </div>
                  </div>
                </div>
              )}

              {/* Multi-Platform URL Inputs */}
              {isMultiMode && (
                <div className="space-y-4">
                  <Label className="text-base font-semibold flex items-center gap-2">
                    <Share2Icon className="h-4 w-4" />
                    URLs de cada plataforma
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    Ingresa las URLs de los posts en cada red social. Puedes habilitar o deshabilitar cada una.
                  </p>

                  <div className="space-y-3">
                    {multiPlatformUrls.map((platformUrl) => (
                      <div
                        key={platformUrl.platform}
                        className={cn(
                          'flex items-center gap-3 p-4 rounded-xl border-2 transition-all',
                          platformUrl.enabled
                            ? 'border-gray-200 bg-white'
                            : 'border-gray-100 bg-gray-50 opacity-60'
                        )}
                      >
                        <button
                          type="button"
                          onClick={() => handleMultiPlatformToggle(platformUrl.platform)}
                          className={cn(
                            'flex h-10 w-10 shrink-0 items-center justify-center rounded-lg text-white transition-all',
                            platformUrl.enabled
                              ? platformConfig[platformUrl.platform].bgClass
                              : 'bg-gray-300'
                          )}
                        >
                          {getPlatformIcon(platformUrl.platform)}
                        </button>
                        <div className="flex-1 min-w-0">
                          <Input
                            value={platformUrl.url}
                            onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                              handleMultiPlatformUrlChange(platformUrl.platform, e.target.value)
                            }
                            placeholder={`URL de ${platformConfig[platformUrl.platform].name}...`}
                            disabled={!platformUrl.enabled}
                            className="h-10 border-0 bg-transparent focus-visible:ring-0 px-0"
                          />
                        </div>
                        <Switch
                          checked={platformUrl.enabled}
                          onCheckedChange={() => handleMultiPlatformToggle(platformUrl.platform)}
                        />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Interaction Types */}
              <div className="space-y-3">
                <Label className="text-base font-semibold flex items-center gap-2">
                  <FilterIcon className="h-4 w-4" />
                  Tipo de Interaccion
                </Label>
                {isMultiMode && (
                  <p className="text-sm text-muted-foreground">
                    Nota: No todas las plataformas soportan todos los tipos. Se aplicaran segun disponibilidad.
                  </p>
                )}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {availableInteractions.map((interaction) => (
                    <button
                      key={interaction}
                      type="button"
                      onClick={() => handleInteractionToggle(interaction)}
                      className={cn(
                        'flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all duration-200',
                        selectedInteractions.includes(interaction)
                          ? 'border-primary bg-primary/5 text-primary'
                          : 'border-gray-200 hover:border-gray-300 text-gray-600'
                      )}
                    >
                      {getInteractionIcon(interaction)}
                      <span className="text-sm font-medium">
                        {interactionConfig[interaction].namePlural}
                      </span>
                      {selectedInteractions.includes(interaction) && (
                        <CheckIcon className="h-4 w-4 text-primary" />
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Settings */}
              <div className="grid md:grid-cols-2 gap-4">
                <Card className="border-2">
                  <CardContent className="p-4 space-y-4">
                    <div className="flex items-center justify-between">
                      <Label className="font-medium">Excluir duplicados</Label>
                      <Switch
                        checked={excludeDuplicates}
                        onCheckedChange={setExcludeDuplicates}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label className="font-medium">Requiere mencion</Label>
                      <Switch
                        checked={requireMention}
                        onCheckedChange={setRequireMention}
                      />
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2">
                  <CardContent className="p-4">
                    <Label className="font-medium">Numero de ganadores</Label>
                    <div className="flex items-center gap-3 mt-3">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setWinnersCount(Math.max(1, winnersCount - 1))}
                        disabled={winnersCount <= 1}
                      >
                        -
                      </Button>
                      <span className="text-2xl font-bold w-12 text-center">
                        {winnersCount}
                      </span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setWinnersCount(Math.min(10, winnersCount + 1))}
                        disabled={winnersCount >= 10}
                      >
                        +
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Start Button */}
              <Button
                onClick={handleLoadParticipants}
                disabled={
                  isLoading ||
                  (!isMultiMode && !postUrl) ||
                  (isMultiMode && !multiPlatformUrls.some((p) => p.enabled && p.url))
                }
                className={cn(
                  'w-full h-14 text-lg font-bold text-white rounded-xl transition-all duration-300',
                  isMultiMode
                    ? 'bg-gradient-to-r from-[#450063] via-[#9414d1] to-[#03b2ed] hover:opacity-90'
                    : platformConfig[platformMode as Platform].bgClass,
                  'hover:scale-[1.02]'
                )}
              >
                {isLoading ? (
                  <span className="flex items-center gap-2">
                    <RefreshIcon className="h-5 w-5 animate-spin" />
                    Cargando participantes...
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    <ArrowRightIcon className="h-5 w-5" />
                    Cargar Participantes
                  </span>
                )}
              </Button>
            </div>
          )}

          {currentStep === 'participants' && (
            <div className="space-y-6">
              {/* Stats */}
              {isMultiMode ? (
                <>
                  {/* Platform Stats */}
                  <div className="grid grid-cols-3 gap-4">
                    {(Object.keys(platformConfig) as Platform[]).map((platform) => {
                      const platformParticipants = getParticipantsByPlatform(platform);
                      if (platformParticipants.length === 0) return null;
                      return (
                        <Card key={platform} className={cn('border-2', platformConfig[platform].bgClass.replace('bg-', 'border-'))}>
                          <CardContent className="p-4 text-center">
                            <div className={cn('flex justify-center mb-2', platformConfig[platform].bgClass, 'rounded-lg p-2 w-fit mx-auto')}>
                              {getPlatformIcon(platform)}
                            </div>
                            <p className="text-2xl font-bold">{platformParticipants.length}</p>
                            <p className="text-sm text-muted-foreground">
                              {platformConfig[platform].name}
                            </p>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>

                  {/* Interaction Stats */}
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                    {selectedInteractions.map((interaction) => {
                      const count = participants.filter(
                        (p) => p.interactionType === interaction
                      ).length;
                      return (
                        <Card key={interaction} className="border-2">
                          <CardContent className="p-4 text-center">
                            <div className="flex justify-center mb-2 text-primary">
                              {getInteractionIcon(interaction)}
                            </div>
                            <p className="text-2xl font-bold">{count}</p>
                            <p className="text-sm text-muted-foreground">
                              {interactionConfig[interaction].namePlural}
                            </p>
                          </CardContent>
                        </Card>
                      );
                    })}
                    <Card className="border-2 border-primary bg-primary/5">
                      <CardContent className="p-4 text-center">
                        <div className="flex justify-center mb-2 text-primary">
                          <UsersIcon className="h-4 w-4" />
                        </div>
                        <p className="text-2xl font-bold text-primary">{participants.length}</p>
                        <p className="text-sm text-primary/70">Total</p>
                      </CardContent>
                    </Card>
                  </div>
                </>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {selectedInteractions.map((interaction) => {
                    const count = participants.filter(
                      (p) => p.interactionType === interaction
                    ).length;
                    return (
                      <Card key={interaction} className="border-2">
                        <CardContent className="p-4 text-center">
                          <div className="flex justify-center mb-2 text-primary">
                            {getInteractionIcon(interaction)}
                          </div>
                          <p className="text-2xl font-bold">{count}</p>
                          <p className="text-sm text-muted-foreground">
                            {interactionConfig[interaction].namePlural}
                          </p>
                        </CardContent>
                      </Card>
                    );
                  })}
                  <Card className="border-2 border-primary bg-primary/5">
                    <CardContent className="p-4 text-center">
                      <div className="flex justify-center mb-2 text-primary">
                        <UsersIcon className="h-4 w-4" />
                      </div>
                      <p className="text-2xl font-bold text-primary">{participants.length}</p>
                      <p className="text-sm text-primary/70">Total</p>
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* Participants Preview */}
              <div className="border-2 rounded-xl p-4 max-h-64 overflow-y-auto">
                <h4 className="font-semibold mb-3 flex items-center gap-2">
                  <UsersIcon className="h-4 w-4" />
                  Participantes ({participants.length})
                </h4>
                <div className="space-y-2">
                  {participants.slice(0, 20).map((participant, index) => (
                    <div
                      key={participant.id}
                      className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50"
                    >
                      <span className="text-sm text-muted-foreground w-6">
                        {index + 1}
                      </span>
                      <img
                        src={participant.avatar}
                        alt={participant.username}
                        className="w-8 h-8 rounded-full"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">@{participant.username}</p>
                        {participant.comment && (
                          <p className="text-sm text-muted-foreground truncate">
                            {participant.comment}
                          </p>
                        )}
                      </div>
                      {isMultiMode && participant.platform && (
                        <span className={cn(
                          'text-white text-xs px-2 py-1 rounded-full',
                          platformConfig[participant.platform]?.bgClass || 'bg-gray-500'
                        )}>
                          {platformConfig[participant.platform]?.name?.slice(0, 2).toUpperCase() || '??'}
                        </span>
                      )}
                      <Badge variant="secondary" className="shrink-0">
                        {getInteractionIcon(participant.interactionType)}
                      </Badge>
                    </div>
                  ))}
                  {participants.length > 20 && (
                    <p className="text-center text-sm text-muted-foreground py-2">
                      ... y {participants.length - 20} participantes mas
                    </p>
                  )}
                </div>
              </div>

              {/* Pick Winners Button */}
              <div className="flex gap-4">
                <Button
                  variant="outline"
                  onClick={() => setCurrentStep('input')}
                  className="flex-1 h-12"
                >
                  Volver
                </Button>
                <Button
                  onClick={handlePickWinners}
                  disabled={isPickingWinner}
                  className={cn(
                    'flex-[2] h-12 text-lg font-bold text-white',
                    isMultiMode
                      ? 'bg-gradient-to-r from-[#450063] via-[#9414d1] to-[#03b2ed]'
                      : platformConfig[platformMode as Platform].bgClass,
                    'hover:opacity-90'
                  )}
                >
                  {isPickingWinner ? (
                    <span className="flex items-center gap-2">
                      <SparklesIcon className="h-5 w-5 animate-pulse" />
                      Seleccionando...
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      <TrophyIcon className="h-5 w-5" />
                      Elegir {winnersCount} Ganador{winnersCount > 1 ? 'es' : ''}
                    </span>
                  )}
                </Button>
              </div>
            </div>
          )}

          {currentStep === 'winner' && (
            <div className="space-y-6">
              {/* Winners Display */}
              <div className="text-center py-8">
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-yellow-100 text-yellow-700 mb-6">
                  <TrophyIcon className="h-5 w-5" />
                  <span className="font-semibold">
                    {winners.length > 1 ? 'Ganadores del Sorteo' : 'Ganador del Sorteo'}
                  </span>
                  {isMultiMode && (
                    <Badge className="bg-gradient-to-r from-[#450063] via-[#9414d1] to-[#03b2ed] text-white border-0">
                      Multi-Red
                    </Badge>
                  )}
                </div>

                <div className="grid gap-4 max-w-lg mx-auto">
                  {winners.map((winner, index) => (
                    <div
                      key={winner.id}
                      className="winner-animation bg-gradient-to-r from-yellow-50 to-amber-50 border-2 border-yellow-200 rounded-2xl p-6"
                      style={{ animationDelay: `${index * 0.2}s` }}
                    >
                      <div className="flex items-center gap-4">
                        <div className="relative">
                          <img
                            src={winner.avatar}
                            alt={winner.username}
                            className="w-16 h-16 rounded-full border-4 border-yellow-400"
                          />
                          <span className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-yellow-400 text-white font-bold flex items-center justify-center text-sm shadow-lg">
                            {winner.position}
                          </span>
                        </div>
                        <div className="text-left flex-1">
                          <p className="text-xl font-bold">@{winner.username}</p>
                          <p className="text-gray-600">{winner.displayName}</p>
                          <div className="flex gap-2 mt-1">
                            {isMultiMode && winner.platform && (
                              <span className={cn(
                                'text-white text-xs px-2 py-1 rounded-full',
                                platformConfig[winner.platform]?.bgClass || 'bg-gray-500'
                              )}>
                                {platformConfig[winner.platform]?.name || 'Unknown'}
                              </span>
                            )}
                            <Badge variant="secondary">
                              {getInteractionIcon(winner.interactionType)}
                              <span className="ml-1">
                                {interactionConfig[winner.interactionType].name}
                              </span>
                            </Badge>
                          </div>
                        </div>
                      </div>
                      {winner.comment && (
                        <p className="mt-3 text-gray-600 italic text-left bg-white p-3 rounded-lg">
                          &ldquo;{winner.comment}&rdquo;
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-wrap gap-3 justify-center">
                <Button variant="outline" className="gap-2" onClick={handlePickWinners}>
                  <RefreshIcon className="h-4 w-4" />
                  Sortear de nuevo
                </Button>
                <Button variant="outline" className="gap-2">
                  <DownloadIcon className="h-4 w-4" />
                  Descargar Certificado
                </Button>
                <Button
                  onClick={handleReset}
                  className={cn(
                    'gap-2 text-white',
                    isMultiMode
                      ? 'bg-gradient-to-r from-[#450063] via-[#9414d1] to-[#03b2ed]'
                      : platformConfig[platformMode as Platform].bgClass
                  )}
                >
                  <ArrowRightIcon className="h-4 w-4" />
                  Nuevo Sorteo
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
