'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { SparklesIcon, MenuIcon, XIcon, ChevronDownIcon } from '@/components/icons';
import { cn } from '@/lib/utils';

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-md">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group">
          <div className="relative flex h-10 w-10 items-center justify-center rounded-xl gradient-primary shadow-lg group-hover:shadow-xl transition-shadow">
            <SparklesIcon className="h-5 w-5 text-white" />
          </div>
          <span className="text-xl font-bold tracking-tight">
            <span className="text-gradient">Sorteos</span>
            <span className="text-gray-800">Pro</span>
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-1">
          <NavDropdown title="Herramientas">
            <NavDropdownItem href="#instagram" icon="instagram">
              Sorteo Instagram
            </NavDropdownItem>
            <NavDropdownItem href="#facebook" icon="facebook">
              Sorteo Facebook
            </NavDropdownItem>
            <NavDropdownItem href="#tiktok" icon="tiktok">
              Sorteo TikTok
            </NavDropdownItem>
            <NavDropdownItem href="#wheel" icon="wheel">
              Rueda de la Fortuna
            </NavDropdownItem>
            <NavDropdownItem href="#names" icon="list">
              Sorteo de Nombres
            </NavDropdownItem>
          </NavDropdown>
          <NavLink href="#como-funciona">Como Funciona</NavLink>
          <NavLink href="#faq">FAQ</NavLink>
        </nav>

        {/* CTA Buttons */}
        <div className="hidden md:flex items-center gap-3">
          <Button variant="ghost" className="font-medium">
            Iniciar Sesion
          </Button>
          <Button className="gradient-primary text-white font-medium shadow-md hover:shadow-lg transition-shadow">
            Comenzar Gratis
          </Button>
        </div>

        {/* Mobile Menu Button */}
        <button
          type="button"
          className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? (
            <XIcon className="h-6 w-6 text-gray-600" />
          ) : (
            <MenuIcon className="h-6 w-6 text-gray-600" />
          )}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden border-t bg-white animate-in slide-in-from-top-2 duration-200">
          <div className="container mx-auto px-4 py-4 space-y-3">
            <MobileNavLink href="#instagram">Sorteo Instagram</MobileNavLink>
            <MobileNavLink href="#facebook">Sorteo Facebook</MobileNavLink>
            <MobileNavLink href="#tiktok">Sorteo TikTok</MobileNavLink>
            <MobileNavLink href="#wheel">Rueda de la Fortuna</MobileNavLink>
            <MobileNavLink href="#como-funciona">Como Funciona</MobileNavLink>
            <MobileNavLink href="#faq">FAQ</MobileNavLink>
            <div className="pt-4 flex flex-col gap-2">
              <Button variant="outline" className="w-full font-medium">
                Iniciar Sesion
              </Button>
              <Button className="w-full gradient-primary text-white font-medium">
                Comenzar Gratis
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}

function NavLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link
      href={href}
      className="px-4 py-2 text-sm font-medium text-gray-600 hover:text-primary rounded-lg hover:bg-gray-50 transition-colors"
    >
      {children}
    </Link>
  );
}

function MobileNavLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link
      href={href}
      className="block px-4 py-3 text-sm font-medium text-gray-700 hover:text-primary hover:bg-gray-50 rounded-lg transition-colors"
    >
      {children}
    </Link>
  );
}

function NavDropdown({ title, children }: { title: string; children: React.ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div
      className="relative"
      onMouseEnter={() => setIsOpen(true)}
      onMouseLeave={() => setIsOpen(false)}
    >
      <button
        type="button"
        className={cn(
          "flex items-center gap-1 px-4 py-2 text-sm font-medium rounded-lg transition-colors",
          isOpen ? "text-primary bg-gray-50" : "text-gray-600 hover:text-primary hover:bg-gray-50"
        )}
      >
        {title}
        <ChevronDownIcon className={cn("h-4 w-4 transition-transform", isOpen && "rotate-180")} />
      </button>

      {isOpen && (
        <div className="absolute top-full left-0 pt-2 w-64 animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="bg-white rounded-xl border shadow-xl p-2">
            {children}
          </div>
        </div>
      )}
    </div>
  );
}

function NavDropdownItem({
  href,
  icon,
  children,
}: {
  href: string;
  icon: string;
  children: React.ReactNode;
}) {
  return (
    <Link
      href={href}
      className="flex items-center gap-3 px-3 py-2.5 text-sm font-medium text-gray-600 hover:text-primary hover:bg-gray-50 rounded-lg transition-colors"
    >
      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gray-100">
        {icon === 'instagram' && <span className="text-[#E4405F]">IG</span>}
        {icon === 'facebook' && <span className="text-[#1877F2]">FB</span>}
        {icon === 'tiktok' && <span className="text-black">TT</span>}
        {icon === 'wheel' && <span className="text-primary">W</span>}
        {icon === 'list' && <span className="text-gray-600">L</span>}
      </span>
      {children}
    </Link>
  );
}
