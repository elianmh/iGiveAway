'use client';

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const faqs = [
  {
    question: 'Que es SorteosPro y como funciona?',
    answer:
      'SorteosPro es una plataforma que permite crear sorteos en redes sociales y seleccionar ganadores aleatoriamente. Soporta Instagram, Facebook y TikTok. Puedes sortear entre comentarios, likes, shares y reposts. Los usuarios pueden crear sorteos ilimitados de forma gratuita.',
  },
  {
    question: 'Como puedo sortear entre likes y shares?',
    answer:
      'A diferencia de otras plataformas, SorteosPro te permite sortear no solo entre comentarios, sino también entre usuarios que dieron like, compartieron o repostearon tu publicación. Simplemente selecciona el tipo de interacción que deseas incluir en el sorteo.',
  },
  {
    question: 'Es gratis usar SorteosPro?',
    answer:
      'Si, SorteosPro es completamente gratis para sorteos básicos. Ofrecemos planes premium para sorteos con más participantes y características avanzadas como filtros personalizados y certificados de ganadores.',
  },
  {
    question: 'Puedo combinar diferentes tipos de interacciones?',
    answer:
      'Si, puedes seleccionar múltiples tipos de interacciones (comentarios, likes, shares, reposts) y combinarlos en un solo sorteo. Todos los participantes que cumplan con al menos una de las interacciones seleccionadas serán incluidos.',
  },
  {
    question: 'Que redes sociales soporta SorteosPro?',
    answer:
      'Actualmente soportamos Instagram, Facebook y TikTok. Cada plataforma tiene diferentes tipos de interacciones disponibles para sortear. Estamos trabajando para agregar más redes sociales próximamente.',
  },
  {
    question: 'Como garantizan que el sorteo sea justo?',
    answer:
      'Utilizamos un algoritmo aleatorio criptográficamente seguro para seleccionar los ganadores. El proceso es transparente y verificable. Al final del sorteo, puedes descargar un certificado con los detalles del sorteo y el ganador.',
  },
  {
    question: 'Puedo filtrar participantes por hashtags o menciones?',
    answer:
      'Si, puedes aplicar filtros avanzados para incluir solo comentarios que contengan hashtags específicos o menciones a otros usuarios. También puedes excluir duplicados y bloquear usuarios no deseados.',
  },
  {
    question: 'Cuantos ganadores puedo seleccionar?',
    answer:
      'Puedes seleccionar hasta 10 ganadores en un solo sorteo. Cada ganador será único y no se repetirá en el mismo sorteo.',
  },
];

export function FAQ() {
  return (
    <section id="faq" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Preguntas Frecuentes
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Todo lo que necesitas saber sobre SorteosPro
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={`faq-${index + 1}`}
                value={`item-${index}`}
                className="bg-white border-2 rounded-xl px-6 data-[state=open]:border-primary/30"
              >
                <AccordionTrigger className="text-left font-semibold hover:no-underline py-5">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pb-5">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
