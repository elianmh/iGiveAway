'use client';

import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  FilterIcon,
  ShieldCheckIcon,
  DownloadIcon,
  HeartIcon,
  Share2Icon,
  RepeatIcon,
  CheckIcon,
} from '@/components/icons';

const features = [
  {
    icon: <HeartIcon className="h-6 w-6" />,
    title: 'Sortea por Likes',
    description: 'No solo comentarios. Sortea entre usuarios que dieron like a tu publicacion.',
    highlight: true,
  },
  {
    icon: <Share2Icon className="h-6 w-6" />,
    title: 'Sortea por Shares',
    description: 'Incluye a usuarios que compartieron tu contenido en sus historias o feed.',
    highlight: true,
  },
  {
    icon: <RepeatIcon className="h-6 w-6" />,
    title: 'Sortea por Reposts',
    description: 'En TikTok, también puedes sortear entre usuarios que repostearon tu video.',
    highlight: true,
  },
  {
    icon: <FilterIcon className="h-6 w-6" />,
    title: 'Filtros Avanzados',
    description: 'Filtra por hashtags, menciones, excluye duplicados y bloquea usuarios.',
    highlight: false,
  },
  {
    icon: <ShieldCheckIcon className="h-6 w-6" />,
    title: 'Sorteo Transparente',
    description: 'Algoritmo aleatorio verificable. Comparte el certificado con tus seguidores.',
    highlight: false,
  },
  {
    icon: <DownloadIcon className="h-6 w-6" />,
    title: 'Certificado de Ganador',
    description: 'Descarga un certificado profesional para compartir en tus redes sociales.',
    highlight: false,
  },
];

const checkItems = [
  'Comentarios que mencionan a un amigo',
  'Comentarios con hashtag específico',
  'Filtrar comentarios duplicados',
  'Bloquear usuarios no deseados',
  'Combinar múltiples interacciones',
  'Seleccionar múltiples ganadores',
];

export function Features() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        {/* Main Feature */}
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-20">
          <div>
            <span className="inline-block px-4 py-1 rounded-full bg-primary/10 text-primary font-medium text-sm mb-4">
              NUEVO: Likes, Shares y Reposts
            </span>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Sortea por cualquier tipo de interaccion
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              A diferencia de otras plataformas, SorteosPro te permite sortear no solo entre
              comentarios, sino también entre{' '}
              <span className="font-semibold text-foreground">likes, shares y reposts</span>.
              Aumenta la participación en tus sorteos incentivando diferentes acciones.
            </p>
            <div className="grid sm:grid-cols-2 gap-3 mb-8">
              {checkItems.map((item, index) => (
                <div key={`check-${index + 1}`} className="flex items-center gap-2">
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary/10 text-primary">
                    <CheckIcon className="h-3 w-3" />
                  </span>
                  <span className="text-sm">{item}</span>
                </div>
              ))}
            </div>
            <Button className="gradient-primary text-white font-semibold px-8 h-12 shadow-lg hover:shadow-xl transition-shadow">
              Probar Gratis
            </Button>
          </div>
          <div className="relative">
            <div className="bg-gradient-to-br from-primary/5 to-primary/10 rounded-3xl p-8">
              <div className="grid grid-cols-2 gap-4">
                {[
                  { type: 'Comments', value: 324 },
                  { type: 'Likes', value: 512 },
                  { type: 'Shares', value: 187 },
                  { type: 'Reposts', value: 224 },
                ].map((item, index) => (
                  <Card
                    key={item.type}
                    className={`border-2 transition-all duration-300 ${
                      index === 0
                        ? 'border-primary bg-primary/5'
                        : 'border-gray-200 hover:border-primary/30'
                    }`}
                  >
                    <CardContent className="p-4 text-center">
                      <p className="text-3xl font-bold mb-1">
                        {item.value}
                      </p>
                      <p className="text-sm text-muted-foreground">{item.type}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
              <div className="mt-4 p-4 bg-white rounded-xl border-2">
                <p className="text-sm text-muted-foreground mb-2">Total Participantes</p>
                <p className="text-4xl font-bold text-primary">1,247</p>
              </div>
            </div>
          </div>
        </div>

        {/* Feature Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card
              key={`feature-${index + 1}`}
              className={`border-2 transition-all duration-300 hover:shadow-lg ${
                feature.highlight
                  ? 'border-primary/20 bg-gradient-to-br from-primary/5 to-transparent'
                  : 'hover:border-primary/30'
              }`}
            >
              <CardContent className="p-6">
                <div
                  className={`inline-flex h-12 w-12 items-center justify-center rounded-xl mb-4 ${
                    feature.highlight
                      ? 'gradient-primary text-white shadow-lg'
                      : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  {feature.icon}
                </div>
                <h3 className="font-bold text-lg mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
