export type Platform = 'instagram' | 'facebook' | 'tiktok' | 'youtube' | 'twitter';

export type InteractionType = 'comments' | 'likes' | 'shares' | 'reposts' | 'subscribers' | 'retweets';

export interface Participant {
  id: string;
  username: string;
  displayName: string;
  avatar?: string;
  interactionType: InteractionType;
  comment?: string;
  timestamp: Date;
  platform?: Platform;
}

export interface GiveawaySettings {
  platform: Platform;
  postUrl: string;
  interactionTypes: InteractionType[];
  winnersCount: number;
  excludeDuplicates: boolean;
  requireMention: boolean;
  requiredHashtags: string[];
  blockedUsers: string[];
}

export interface Winner extends Participant {
  position: number;
}

export interface GiveawayResult {
  id: string;
  settings: GiveawaySettings;
  participants: Participant[];
  winners: Winner[];
  createdAt: Date;
}

export interface Tool {
  id: string;
  name: string;
  description: string;
  icon: string;
  platform?: Platform;
  href: string;
}

export const platformConfig: Record<Platform, {
  name: string;
  color: string;
  bgClass: string;
  textClass: string;
  icon: string;
  supportedInteractions: InteractionType[];
}> = {
  instagram: {
    name: 'Instagram',
    color: '#E4405F',
    bgClass: 'bg-instagram',
    textClass: 'text-instagram',
    icon: 'instagram',
    supportedInteractions: ['comments', 'likes'],
  },
  facebook: {
    name: 'Facebook',
    color: '#1877F2',
    bgClass: 'bg-facebook',
    textClass: 'text-facebook',
    icon: 'facebook',
    supportedInteractions: ['comments', 'likes', 'shares'],
  },
  tiktok: {
    name: 'TikTok',
    color: '#000000',
    bgClass: 'bg-tiktok',
    textClass: 'text-tiktok',
    icon: 'tiktok',
    supportedInteractions: ['comments', 'likes', 'shares', 'reposts'],
  },
  youtube: {
    name: 'YouTube',
    color: '#FF0000',
    bgClass: 'bg-youtube',
    textClass: 'text-youtube',
    icon: 'youtube',
    supportedInteractions: ['comments', 'likes', 'subscribers'],
  },
  twitter: {
    name: 'Twitter/X',
    color: '#000000',
    bgClass: 'bg-twitter',
    textClass: 'text-twitter',
    icon: 'twitter',
    supportedInteractions: ['comments', 'likes', 'retweets'],
  },
};

export const interactionConfig: Record<InteractionType, {
  name: string;
  namePlural: string;
  icon: string;
  description: string;
}> = {
  comments: {
    name: 'Comment',
    namePlural: 'Comments',
    icon: 'message-circle',
    description: 'Pick winners from post comments',
  },
  likes: {
    name: 'Like',
    namePlural: 'Likes',
    icon: 'heart',
    description: 'Pick winners from users who liked',
  },
  shares: {
    name: 'Share',
    namePlural: 'Shares',
    icon: 'share-2',
    description: 'Pick winners from users who shared',
  },
  reposts: {
    name: 'Repost',
    namePlural: 'Reposts',
    icon: 'repeat',
    description: 'Pick winners from users who reposted',
  },
  subscribers: {
    name: 'Subscriber',
    namePlural: 'Subscribers',
    icon: 'user-plus',
    description: 'Pick winners from channel subscribers',
  },
  retweets: {
    name: 'Retweet',
    namePlural: 'Retweets',
    icon: 'repeat',
    description: 'Pick winners from users who retweeted',
  },
};
