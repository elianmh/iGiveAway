import type { Participant, InteractionType } from './types';

const firstNames = [
  'Emma', 'Liam', 'Olivia', 'Noah', 'Ava', 'William', 'Sophia', 'James', 'Isabella', 'Oliver',
  'Mia', 'Benjamin', 'Charlotte', 'Elijah', 'Amelia', 'Lucas', 'Harper', 'Mason', 'Evelyn', 'Logan',
  'Maria', 'Carlos', 'Ana', 'Luis', 'Sofia', 'Diego', 'Valentina', 'Miguel', 'Camila', 'Andres',
  'Lucia', 'Pablo', 'Elena', 'Mateo', 'Isabella', 'Daniel', 'Victoria', 'Adrian', 'Natalia', 'Sebastian',
  'Marco', 'Giulia', 'Alessandro', 'Francesca', 'Lorenzo', 'Chiara', 'Andrea', 'Sara', 'Luca', 'Anna',
];

const lastNames = [
  'Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez',
  'Hernandez', 'Lopez', 'Gonzalez', 'Wilson', 'Anderson', 'Thomas', 'Taylor', 'Moore', 'Jackson', 'Martin',
  'Lee', 'Perez', 'Thompson', 'White', 'Harris', 'Sanchez', 'Clark', 'Ramirez', 'Lewis', 'Robinson',
];

const commentTemplates = [
  'Me encanta! Quiero participar',
  'Increible! Ojala gane',
  'Siguiendo todas las reglas! @{friend}',
  'Participando! @{friend} @{friend2}',
  'Que hermoso regalo! Ya comparto',
  'Listo! Etiqueto a @{friend}',
  'Espero ganar! @{friend}',
  'Que buena oportunidad! Participo',
  'Ya estoy siguiendo! @{friend}',
  'Compartido! Ojala tenga suerte',
  'Quiero ese premio! @{friend} @{friend2}',
  'Participando con todo!',
  'Me apunto! @{friend}',
  'Excelente sorteo! Participo',
  'Ya di like y comparto @{friend}',
];

function generateUsername(firstName: string, lastName: string): string {
  const styles = [
    () => `${firstName.toLowerCase()}${lastName.toLowerCase()}`,
    () => `${firstName.toLowerCase()}_${lastName.toLowerCase()}`,
    () => `${firstName.toLowerCase()}${Math.floor(Math.random() * 999)}`,
    () => `${firstName.toLowerCase()}.${lastName.toLowerCase().slice(0, 3)}`,
    () => `the_${firstName.toLowerCase()}`,
    () => `${firstName.toLowerCase()}official`,
  ];
  return styles[Math.floor(Math.random() * styles.length)]();
}

function generateComment(): string {
  const template = commentTemplates[Math.floor(Math.random() * commentTemplates.length)];
  return template
    .replace('{friend}', `@${generateRandomName().toLowerCase()}`)
    .replace('{friend2}', `@${generateRandomName().toLowerCase()}`);
}

function generateRandomName(): string {
  return firstNames[Math.floor(Math.random() * firstNames.length)];
}

export function generateMockParticipants(count: number, interactionType: InteractionType): Participant[] {
  const participants: Participant[] = [];
  const usedUsernames = new Set<string>();

  for (let i = 0; i < count; i++) {
    const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
    const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
    let username = generateUsername(firstName, lastName);

    while (usedUsernames.has(username)) {
      username = generateUsername(firstName, lastName);
    }
    usedUsernames.add(username);

    participants.push({
      id: `participant-${i}-${Date.now()}`,
      username,
      displayName: `${firstName} ${lastName}`,
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`,
      interactionType,
      comment: interactionType === 'comments' ? generateComment() : undefined,
      timestamp: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
    });
  }

  return participants.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
}

export function pickRandomWinners<T>(array: T[], count: number): T[] {
  const shuffled = [...array].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, Math.min(count, array.length));
}
