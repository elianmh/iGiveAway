import type { Metadata } from "next";
import "./globals.css";
import ClientBody from "./ClientBody";

export const metadata: Metadata = {
  title: "SorteosPro - Sorteos de Instagram, Facebook y TikTok Gratis",
  description: "Crea sorteos gratuitos de redes sociales. Elige ganadores de comentarios, likes, shares y reposts de Instagram, Facebook y TikTok. 100% gratis y transparente.",
  keywords: "sorteos, giveaway, instagram, facebook, tiktok, comentarios, likes, shares, reposts, gratis",
  openGraph: {
    title: "SorteosPro - Sorteos de Redes Sociales",
    description: "Elige ganadores de comentarios, likes, shares y reposts",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <body className="antialiased">
        <ClientBody>{children}</ClientBody>
      </body>
    </html>
  );
}
