import { Header } from '@/components/header';
import { Hero } from '@/components/hero';
import { GiveawayPicker } from '@/components/giveaway-picker';
import { ToolsGrid } from '@/components/tools-grid';
import { Features } from '@/components/features';
import { HowItWorks } from '@/components/how-it-works';
import { FAQ } from '@/components/faq';
import { Footer } from '@/components/footer';

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <Hero />

        {/* Main Giveaway Tool Section */}
        <section className="py-16 md:py-24 bg-white" id="sorteo">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <span className="inline-block px-4 py-1 rounded-full bg-primary/10 text-primary font-medium text-sm mb-4">
                Herramienta Principal
              </span>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Crea tu Sorteo Ahora
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Selecciona la plataforma, ingresa el post y elige entre comentarios, likes,
                shares o reposts para tu sorteo
              </p>
            </div>
            <GiveawayPicker />
          </div>
        </section>

        <ToolsGrid />
        <Features />
        <HowItWorks />
        <FAQ />
      </main>
      <Footer />
    </div>
  );
}
